#ifndef __ASM_SH_EDOSK7705_H
#define __ASM_SH_EDOSK7705_H

#define __IO_PREFIX sh_edosk7705
#include <asm/io_generic.h>

#endif /* __ASM_SH_EDOSK7705_H */
